#include "Customer.cpp"
#include "Customer.h"
#include "Transaction.cpp"
#include "Transaction.h"
#include "LinkedQueue.cpp"
#include "LinkedQueue.h"
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <memory>

int main()
{
    Customer c1(1, "Tarcisius", "Daniel");
    Transaction t1('B', 'D', "Pirates of The Caribbean");
    cout << c1.getFirstName() << endl;
    cout << t1.getMediaType() << endl;
    c1.addHistory(t1);
    c1.printHistory();
    return 0;
}